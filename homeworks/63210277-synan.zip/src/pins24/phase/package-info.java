/**
 * Posamezne faze prevajalnika.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package pins24.phase;