/**
 * Koda, ki je skupna vecim fazam prevajalnika.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package pins24.common;