/**
 * Implementacija programskega jezika PINS'24.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
module pins24 {
}